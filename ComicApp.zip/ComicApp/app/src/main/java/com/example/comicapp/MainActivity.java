package com.example.comicapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.widget.GridView;
import android.widget.ListAdapter;
import android.widget.SearchView;
import android.widget.Toast;

import com.example.comicapp.API.ComicApiEndPoint;
import com.example.comicapp.adapter.ComicAdapter;
import com.example.comicapp.object.Comic;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rcvComic;

    private ComicAdapter comicAdapter;

    private SearchView searchView;

    private List<Comic> mListComic;

    private void BindingView() {
        rcvComic = findViewById(R.id.comicList);
        searchView = findViewById(R.id.searchView);
        mListComic = new ArrayList<>();
    }

    private void BindingAction() {
        searchView.clearFocus();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filterList(newText);
                return true;
            }
        });
    }

    private void filterList(String text) {
        mListComic = getListComic();
        List<Comic> filterList = new ArrayList<>();
        for (Comic c : mListComic) {
            if (c.getComicName().toLowerCase().contains(text.toLowerCase())) {
                filterList.add(c);
            }
        }
        if (filterList.isEmpty()) {
            Toast.makeText(this, "No data", Toast.LENGTH_SHORT).show();
            comicAdapter.setData(null);
        } else {
            comicAdapter.setData(filterList);
        }
        rcvComic.setAdapter(null);
        rcvComic.setAdapter(comicAdapter);
    }

    private List<Comic> getListComic() {
        mListComic.add(new Comic("VÕ LUYỆN ĐỈNH PHONG", "Chap 1", "https://st.nettruyenmax.com/data/comics/32/vo-luyen-dinh-phong.jpg"));
        mListComic.add(new Comic("NHẤT KIẾM ĐỘC TÔN", "Chap 1", "https://st.nettruyenmax.com/data/comics/232/nhat-kiem-doc-ton.jpg"));
        mListComic.add(new Comic("SIEU PHÀM TIẾN HÓA", "Chap 1", "https://st.nettruyenmax.com/data/comics/103/sieu-pham-tien-hoa.jpg"));
        mListComic.add(new Comic("KARATE SHOUKOUSHI KOHINATA MINORU", "Chap 1", "https://st.nettruyenmax.com/data/comics/115/karate-shoukoushi-kohinata-minoru.jpg"));
        mListComic.add(new Comic("THẢNH THƠI THÚ THẾ CHỦNG CHỦNG ĐIỀN, SINH SINH TỂ", "Chap 1", "https://st.nettruyenmax.com/data/comics/153/thanh-thoi-thu-the-chung-chung-dien-sinh-2875.jpg"));
        mListComic.add(new Comic("HỆT NHƯ HÀN QUANG GẶP NẮNG GẮT", "Chap 1", "https://st.nettruyenmax.com/data/comics/87/het-nhu-han-quang-gap-nang-gat.jpg"));
        mListComic.add(new Comic("NGƯỜI TRÊN VẠN NGƯỜI", "Chap 1", "https://st.nettruyenmax.com/data/comics/208/nguoi-tren-van-nguoi.jpg"));
        mListComic.add(new Comic("TA KHÔNG MUỐN TRÙNG SINH ĐÂU", "Chap 1", "https://st.nettruyenmax.com/data/comics/249/ta-khong-muon-trung-sinh-dau.jpg"));
        mListComic.add(new Comic("BIÊN KỊCH THIÊN TÀI", "Chap 1", "https://st.nettruyenmax.com/data/comics/67/bien-kich-thien-tai.jpg"));
        mListComic.add(new Comic("VÕ ĐẠO ĐỘC TÔN", "Chap 1", "https://st.nettruyenmax.com/data/comics/228/vo-dao-doc-ton-7886.jpg"));
        return mListComic;
    }

    private void listComicApi() {
        ComicApiEndPoint.apiservice.getAllComics().enqueue(new Callback<List<Comic>>() {
            @Override
            public void onResponse(Call<List<Comic>> call, Response<List<Comic>> response) {
                List<Comic> list = new ArrayList<>();
                list = response.body();
                comicAdapter = new ComicAdapter(MainActivity.this);
                GridLayoutManager gridLayoutManager = new GridLayoutManager(MainActivity.this, 3);
                rcvComic.setLayoutManager(gridLayoutManager);
                comicAdapter.setData(list);
                rcvComic.setAdapter(comicAdapter);
                Toast.makeText(MainActivity.this, "dang lay ve", Toast.LENGTH_SHORT).show();
            }
            @Override
            public void onFailure(Call<List<Comic>> call, Throwable t) {
                Toast.makeText(MainActivity.this, "Fail", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void initGridView() {
        comicAdapter = new ComicAdapter(this);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 3);
        rcvComic.setLayoutManager(gridLayoutManager);
        comicAdapter.setData(getListComic());
        rcvComic.setAdapter(comicAdapter);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BindingView();
        BindingAction();
       //initGridView();
        listComicApi();
    }
}