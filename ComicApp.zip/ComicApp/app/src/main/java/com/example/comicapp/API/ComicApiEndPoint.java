package com.example.comicapp.API;

import com.example.comicapp.object.Comic;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.List;

import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ComicApiEndPoint {
//    @GET("api/Comic")
//    Call<List<Comic>> getAllComics();
    Gson gson = new GsonBuilder().setDateFormat("dd-MM-yyyy").create();

    ComicApiEndPoint apiservice = new Retrofit.Builder()
            .baseUrl("https://64adcbcab470006a5ec669f4.mockapi.io/")
            .addConverterFactory(GsonConverterFactory.create(gson))
            .build()
            .create(ComicApiEndPoint.class);

        @GET("api/Comic")
    Call<List<Comic>> getAllComics();
}
