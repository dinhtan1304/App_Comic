//package com.example.comicapp;
//
//import com.example.comicapp.API.ComicApiEndPoint;
//
//import retrofit2.Retrofit;
//import retrofit2.converter.gson.GsonConverterFactory;
//
//public class APIServices {
//    public static final String BASE_URL = "https://64adcbcab470006a5ec669f4.mockapi.io/";
//    private Retrofit retrofit;
//
//    private ComicApiEndPoint comicApiEndPoint;
//
//    public APIServices() {
//        retrofit = new Retrofit.Builder().baseUrl(BASE_URL)
//                .addConverterFactory(GsonConverterFactory.create())
//                .build();
//        comicApiEndPoint = retrofit.create(ComicApiEndPoint.class);
//    }
//
//    private static APIServices instance = null;
//    public static APIServices getInstance() {
//        if (instance == null) {
//            instance = new APIServices();
//        }
//        return instance;
//    }
//
//    public ComicApiEndPoint getComicsApiEndPoint() {
//        return comicApiEndPoint;
//    }
//
//    public static ComicApiEndPoint getComicApiEndPoint() {
//        return getInstance().getComicsApiEndPoint();
//    }
//}
